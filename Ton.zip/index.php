<?php
include 'config.php';
include 'functions.php'; 

$update = json_decode(file_get_contents("php://input"), true);

// 1. معالجة طلب الدفع المسبق لنجوم تليجرام (Pre-Checkout)
if (isset($update['pre_checkout_query'])) {
    bot('answerPreCheckoutQuery', ['pre_checkout_query_id' => $update['pre_checkout_query']['id'], 'ok' => true]);
    exit;
}

if (!isset($update['message'])) exit;
$msg = $update['message'];
$chat_id = $msg['chat']['id'];
$user_id = $msg['from']['id'];
$text = $msg['text'] ?? "";

// 2. استقبال طلبات توليد الفواتير القادمة من محرك الـ WebApp
if (isset($msg['web_app_data'])) {
    $data = json_decode($msg['web_app_data']['data'], true);
    
    if (isset($data['action']) && $data['action'] == 'buy_flash_deal') {
        $deal_title = $data['deal_name'];
        $deal_price = (int)$data['price'];
        
        bot('sendInvoice', [
            'chat_id' => $chat_id,
            'title' => "🔥 " . $deal_title,
            'description' => "Immediate dispatch protocol for Elite VIP Hardware Cluster. Bypasses all standard verification hold times instantly.",
            'payload' => "flash_deal_" . $deal_title,
            'provider_token' => "", 
            'currency' => "XTR", 
            'prices' => json_encode([['label' => "Promo Core Lease", 'amount' => $deal_price]])
        ]);
        exit;
    }
}

// 3. جلب وتأسيس بيانات المستخدم
$u = firebase("users/$user_id");

if (!$u) {
    $ref = (strpos($text, '/start ') === 0) ? substr($text, 7) : null;
    $u = [
        'id' => $user_id, 
        'balances' => $initial_balances, 
        'speeds' => $default_speeds,     
        'last_t' => microtime(true), 
        'streak' => 0,            
        'last_checkin' => 0,      
        'miner_level' => 1,       
        'lang' => 'en', 
        'verified' => false
    ];
    firebase("users/$user_id", "PUT", $u);
    
    if ($ref && $ref != $user_id) {
        $r_d = firebase("users/$ref");
        if ($r_d && isset($r_d['balances']['TON'])) {
            $r_d['balances']['TON'] += $refBonus; 
            firebase("users/$ref", "PATCH", ['balances' => $r_d['balances']]); 
        }
    }
} else {
    if (!isset($u['lang']) || $u['lang'] != 'en') {
        $u['lang'] = 'en';
        firebase("users/$user_id", "PATCH", ['lang' => 'en']);
    }
}

// 4. محرك استمرارية التعدين التراكمي
$now = microtime(true);
$last_interaction = isset($u['last_t']) ? $u['last_t'] : $now;
$diff = $now - $last_interaction; 

$level_multiplier = 1 + (($u['miner_level'] ?? 1) - 1) * 0.25;
$vip_status_multiplier = (isset($u['verified']) && $u['verified'] == true) ? $vipMultiplier : 1;

$updated_balances = [];
$currency_list = ['TON', 'STARS', 'NOT', 'LTC', 'BNB', 'DOGE'];

foreach ($currency_list as $coin) {
    $current_bal = isset($u['balances'][$coin]) ? (float)$u['balances'][$coin] : 0.0;
    $base_speed = isset($u['speeds'][$coin]) ? (float)$u['speeds'][$coin] : $default_speeds[$coin];
    
    $actual_speed = $base_speed * $level_multiplier * $vip_status_multiplier;
    $earned = $diff * $actual_speed;
    $updated_balances[$coin] = $current_bal + $earned;
}

firebase("users/$user_id", "PATCH", [
    'balances' => $updated_balances, 
    'last_t' => $now
]);

$f_ton   = number_format($updated_balances['TON'], 8, '.', '');
$f_stars = number_format($updated_balances['STARS'], 4, '.', '');
$f_not   = number_format($updated_balances['NOT'], 2, '.', '');
$f_ltc   = number_format($updated_balances['LTC'], 8, '.', '');
$f_bnb   = number_format($updated_balances['BNB'], 8, '.', '');
$f_doge  = number_format($updated_balances['DOGE'], 4, '.', '');

$payout_alert = fakePayout('en');

$ln = [
    'text' => "🚀 **Web3 Cloud Mining Hub (v3.5)**\n\n$payout_alert\n\n💰 **Live Clusters Balance:**\n💎 `TON: $f_ton` | ⭐️ `STARS: $f_stars` \n🪙 `NOT: $f_not` | ⚡️ `LTC: $f_ltc`\n🔶 `BNB: $f_bnb` | 🐕 `DOGE: $f_doge`\n\n🛠 **Hardware Level:** `Level " . ($u['miner_level'] ?? 1) . " Server`\n🔥 **Daily Check-in:** `" . ($u['streak'] ?? 0) . " Days Streak`",
    'btn_webapp' => "🎮 Open Web3 Terminal",
    'btn_boost' => "⚡️ Claim Daily Speed Boost",
    'menu_main' => "🚀 Mining Dashboard",
    'menu_ref' => "👤 Referrals",
    'menu_vip' => "💎 Upgrade VIP",
    'menu_with' => "💳 Withdraw",
    'menu_tasks' => "🎁 Earn Stars/TON"
];

$reply_keyboard = [
    [ ["text" => $ln['menu_main']] ],
    [ ["text" => $ln['menu_ref']], ["text" => $ln['menu_vip']] ],
    [ ["text" => $ln['menu_tasks']], ["text" => $ln['menu_with']] ]
];

if (strpos($text, "/start") === 0 || $text == $ln['menu_main']) {
    $web_app_url = "https://easycoin.ink/interface.html?user_id=$user_id&ton_bal=$f_ton&ton_speed={$u['speeds']['TON']}&stars_bal=$f_stars&stars_speed={$u['speeds']['STARS']}&not_bal=$f_not&not_speed={$u['speeds']['NOT']}&ltc_bal=$f_ltc&ltc_speed={$u['speeds']['LTC']}&bnb_bal=$f_bnb&bnb_speed={$u['speeds']['BNB']}&doge_bal=$f_doge&doge_speed={$u['speeds']['DOGE']}&streak=".($u['streak']??0)."&lvl=".($u['miner_level']??1)."&diff=".urlencode($diff)."&v=3.5";
    $ad_link = "https://www.effectivecpmnetwork.com/fa5ta0a1?key=218ce1ae9cdc3d5dd3d5af344bd82243";

    bot('sendMessage', [
        'chat_id' => $chat_id, 
        'text' => $ln['text'], 
        'parse_mode' => 'Markdown', 
        'reply_markup' => json_encode([
            'keyboard' => $reply_keyboard, 
            'resize_keyboard' => true,
            'one_time_keyboard' => false
        ])
    ]);
    
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "👇 **Access your terminal nodes below:**",
        'reply_markup' => json_encode([
            'inline_keyboard' => [
                [['text' => $ln['btn_webapp'], 'web_app' => ['url' => $web_app_url]]],
                [['text' => $ln['btn_boost'], 'url' => $ad_link]]
            ]
        ])
    ]);
} 
elseif ($text == $ln['menu_ref']) { 
    $ref_url = "https://t.me/" . $botUsername . "?start=" . $user_id; 
    bot('sendMessage', ['chat_id' => $chat_id, 'text' => "👥 **Referral Hub**\n\nInvite friends using your link and receive instant `0.5 TON`!\n\n🔗 Link:\n$ref_url", 'parse_mode' => 'Markdown']);
} 
elseif ($text == $ln['menu_vip']) { 
    sendStarsInvoice($chat_id, 'en'); 
} 
elseif ($text == $ln['menu_with']) { 
    bot('sendMessage', ['chat_id' => $chat_id, 'text' => "⏳ **STANDARD QUEUE ACTIVE.** Your current node is placed at entry position `#4,851`. Average hold time: `24 Days`.\n\n⚠️ **To bypass hold periods immediately, switch to VIP Terminal Node routing.**", 'parse_mode' => 'Markdown']); 
}
elseif ($text == $ln['menu_tasks']) {
    $task_ad_link = "https://www.effectivecpmnetwork.com/fa5ta0a1?key=218ce1ae9cdc3d5dd3d5af344bd82243";
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => "🎁 **Daily Power Quests**\n\nComplete actions below to boost your cloud speed:",
        'parse_mode' => 'Markdown',
        'reply_markup' => json_encode(['inline_keyboard' => [
            [['text' => "🔥 Watch Ad video (+2X Speed)", 'url' => $task_ad_link]],
            [['text' => "📢 Follow Hub", 'url' => "https://t.me/" . str_replace('@', '', $channel_id)]] 
        ]])
    ]);
}

// 6. استقبال معالجة نجاح دفع الفواتير
if (isset($msg['successful_payment'])) {
    $payload = $msg['successful_payment']['invoice_payload'];
    
    if (strpos($payload, 'flash_deal_') === 0) {
        $activated_deal = str_replace('flash_deal_', '', $payload);
        
        $flash_speeds = [];
        foreach ($default_speeds as $coinName => $baseSpeedValue) {
            $flash_speeds[$coinName] = $baseSpeedValue * 35; 
        }
        
        firebase("users/$user_id", "PATCH", [
            'speeds' => $flash_speeds,
            'miner_level' => 5, 
            'verified' => true
        ]); 
        
        bot('sendMessage', [
            'chat_id' => $chat_id, 
            'text' => "⚡️ **PROMOTION DEPLOYED!** Your cluster has enabled **$activated_deal** with Overclocking Multiplier active at 35X speed matrix!"
        ]);
    } else {
        $vip_speeds = [];
        foreach ($default_speeds as $coinName => $baseSpeedValue) {
            $vip_speeds[$coinName] = $baseSpeedValue * $vipMultiplier;
        }
        firebase("users/$user_id", "PATCH", [
            'speeds' => $vip_speeds,
            'verified' => true
        ]); 
        bot('sendMessage', ['chat_id' => $chat_id, 'text' => "⚡ VIP Active! Hardware core arrays multiplied 15X globally!"]);
    }
}
?>
