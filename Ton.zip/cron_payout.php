<?php
include 'config.php';
include 'functions.php';

$countries = ['🇺🇸', '🇬🇧', '🇷🇺', '🇳🇬', '🇩🇪', '🇮🇳', '🇪🇬', '🇵🇰', '🇧🇷', '🇫🇷', '🇹🇷', '🇺🇿'];

$coin_pool = [
    'TON' => ['icon' => '💎', 'min' => 5.5, 'max' => 35.0, 'decimals' => 2, 'wallet_prefix' => 'EQ'],
    'STARS' => ['icon' => '⭐', 'min' => 250, 'max' => 5000, 'decimals' => 0, 'wallet_prefix' => 'ST'],
    'NOT' => ['icon' => '🪙', 'min' => 1500, 'max' => 25000, 'decimals' => 0, 'wallet_prefix' => 'UQ'],
    'LTC' => ['icon' => '⚡', 'min' => 0.45, 'max' => 4.2, 'decimals' => 4, 'wallet_prefix' => 'LTC'],
    'BNB' => ['icon' => '🔶', 'min' => 0.05, 'max' => 0.65, 'decimals' => 4, 'wallet_prefix' => '0x'],
    'DOGE' => ['icon' => '🐕', 'min' => 350, 'max' => 4500, 'decimals' => 1, 'wallet_prefix' => 'D']
];

$selected_coin = array_rand($coin_pool);
$coin = $coin_pool[$selected_coin];

$n = generateSmartName();
$c = $countries[array_rand($countries)];

$random_value = lcg_value() * ($coin['max'] - $coin['min']) + $coin['min'];
$amount = number_format($random_value, $coin['decimals'], '.', '');
$wallet = $coin['wallet_prefix'] . substr(md5(time() . $n), 0, 8) . "..." . substr(md5($n), -4);

$is_vip = (rand(1, 10) > 4); 

if ($is_vip) {
    $status = "✅ **Instant Payout Dispatched (VIP)**";
    $note = "⚡️ **Network Speed:** `Instant (5 Minutes Settlement)`";
    $badge = "🌟 [VIP HARDWARE NODE]";
} else {
    $status = "⏳ **Payout Queued (Standard)**";
    $note = "⏳ **Network Speed:** `24 Days Standard Hold Hold`";
    $badge = "👤 [Standard Free User]";
}

$text = "$status\n\n"
      . "👤 **User:** `$n` $c\n"
      . "🏅 **Rank:** $badge\n"
      . "💰 **Amount:** `{$coin['icon']} $amount $selected_coin` \n"
      . "💳 **To Destination:** `$wallet` \n"
      . "$note\n\n"
      . "💎 **Join & Start Mining:** $bot_link";

bot('sendMessage', [
    'chat_id' => $channel_id,
    'text' => $text,
    'parse_mode' => 'Markdown'
]);

echo "Success: Dispatched $selected_coin payout log for user $n to channel.";
?>
